/// ques:
void main(){

}